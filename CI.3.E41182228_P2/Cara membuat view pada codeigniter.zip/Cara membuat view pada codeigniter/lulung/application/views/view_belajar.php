<!DOCTYPE html>
<html>
<head>
	<title>Cara Membuat View Pada CodeIgniter | MalasNgoding.com</title>
</head>
<body>
	<h1>Cara Membuat View Pada CodeIgniter</h1>
	<h2>Ini adalah view view_belajar.php</h2>
	<h3>Ini adalah view yang di tampilkan pada controller belajar, method halo</h3>
</body>
</html>