<!DOCTYPE html>
<html>
<head>
	<title>Cara Membuat View Pada CodeIgniter | MalasNgoding.com</title>
</head>
<body>
	<h1>Tugas <?= $nama_web; ?></h1>
</body>
</html>