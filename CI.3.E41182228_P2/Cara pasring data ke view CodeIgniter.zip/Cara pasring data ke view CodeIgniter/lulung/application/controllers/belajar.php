<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Belajar extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		
	}
 
	public function index(){
		echo "method index di controler belajar";
	}
 
	public function halo(){
		$data['nama_web']	= "Pratikum Lulung Satrio Prayuda E41182228";
		$this->load->view('view_belajar',$data);
	}
 
}