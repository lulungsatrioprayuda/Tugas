<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menghubungkan model pada codeigniter</title>
</head>
<body>
    <h1>Mengenal model pada code oigniter dengan database mysql</h1>
    <table border="1">
        <tr>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Pekerjaan</th>
        </tr>
        <?php foreach($user as $u){?>
        <tr>
            <td><?= $u->nama?></td>
            <td><?= $u->alamat?></td>
            <td><?= $u->pekerjaan?></td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>