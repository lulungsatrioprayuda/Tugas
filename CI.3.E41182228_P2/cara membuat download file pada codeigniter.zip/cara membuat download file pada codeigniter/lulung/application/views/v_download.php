<!DOCTYPE html>
<html>
<head>
	<title>Membuat download file dengan codeigniter | MalasNgoding.com</title>
</head>
<body>
	<h1>Membuat download file dengan codeigniter | MalasNgoding.com</h1>
 
	<br/>
 
	<a href="<?php echo base_url().'index.php/download/lakukan_download' ?>">Download file</a>
</body>
</html>