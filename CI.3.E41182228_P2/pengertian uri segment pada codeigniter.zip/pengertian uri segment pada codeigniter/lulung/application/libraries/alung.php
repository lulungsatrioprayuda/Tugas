<?php

class Alung{
    function nama_saya(){
        echo   "Nama saya adalah Lulung satrio prayuda !";
    }
    function nama_kamu($nama){
        echo "nama kamu adalah ". $nama ." !";
    }
}