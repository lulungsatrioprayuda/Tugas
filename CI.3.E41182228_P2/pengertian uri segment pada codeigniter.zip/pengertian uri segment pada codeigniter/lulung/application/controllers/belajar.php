<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Belajar extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('datasql');
		
	}
 
	public function user(){
		$data['user']	=	$this->datasql->ambil_data()->result();
		$this->load->view('v_user.php',$data);
	}
 
	public function halo(){
		// $this->load->view('view_belajar');
	}
 
}