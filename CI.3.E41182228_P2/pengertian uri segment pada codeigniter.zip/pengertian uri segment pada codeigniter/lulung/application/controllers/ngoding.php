<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ngoding extends CI_Controller {
    function index(){
        $this->load->library('alung');
        $this->alung->nama_saya();
        echo   "<br/>";
        $this->alung->nama_kamu("nama orang");
    }
}