<!DOCTYPE html>
<html>
<head>
	<title>Cara Membuat Heading dengan Helper HTML Codeigniter | MalasNgoding.com</title>
</head>
<body>
	<?php 
	echo heading("Helper HTML CodeIgniter | MalasNgoding.com",1);
	echo heading("Helper HTML CodeIgniter | MalasNgoding.com",2);
	echo heading("Helper HTML CodeIgniter | MalasNgoding.com",3);
	echo heading("Helper HTML CodeIgniter | MalasNgoding.com",4);
	echo heading("Helper HTML CodeIgniter | MalasNgoding.com",5);
	echo heading("Helper HTML CodeIgniter | MalasNgoding.com",6);
	?>
</body>
</html>