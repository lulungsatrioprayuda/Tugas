<!DOCTYPE html>
<html>
<head>
	<title>Cara Membuat View Pada CodeIgniter | MalasNgoding.com</title>
</head>
<body>
	<h1>Tugas <?= $judul; ?></h1>
	<h3>Tugas <?= $tutorial; ?></h3>
</body>
</html>